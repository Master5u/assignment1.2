package ac.liv.csc.comp201.simulate;

public interface Temp {


}